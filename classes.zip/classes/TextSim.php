<?php

/**
 * Text Similar
 */
class TextSim
{
    public $NEWS_1;
    public $NEWS_2;

    private $mNewsContent1;
    private $mNewsContent2;

    private $stopWords;

    /**
     * Constructor
     */
    function __construct()
    {
        $this->NEWS_1 = 1;
        $this->NEWS_2 = 2;
        $this->mNewsContent1 = "";
        $this->mNewsContent2 = "";
        // open stop word file and create stop words array
        $this->stopWords = $this->openStopWords();
    }

    /**
     * Destructor
     */
    function __destruct()
    {
        $this->mNewsContent1 = "";
        $this->mNewsContent2 = "";
        $this->stopWords = null;
    }

    /**
     * Open File and Read the Content
     *
     * @param [type] $filePath
     * @return string
     */
    public function openFile($filePath)
    {
        $mFile = fopen($filePath, "r") or die("مشکلی در بازگشایی فایل رخ داد!");
        $content = fread($mFile, filesize($filePath));
        fclose($mFile);
        return $content;
    }

    /**
     * Set News Content
     *
     * @param [type] $index, for each news please use the NEWS_x Variable
     * @param [type] $content, String content of news
     * @return void
     */
    public function setNewsContent($index, $content)
    {
        if ($index == $this->NEWS_1) {
            $this->mNewsContent1 = $content;
        } else if ($index == $this->NEWS_2) {
            $this->mNewsContent2 = $content;
        }
    }

    public function runSim()
    {   
        // remove \n from news content
        $this->mNewsContent1 = $this->removeCharString($this->mNewsContent1, "\n");
        $this->mNewsContent2 = $this->removeCharString($this->mNewsContent2, "\n");

        // convert string to array of words
        $mArray1 = $this->splitToArray($this->mNewsContent1, " ");
        $mArray2 = $this->splitToArray($this->mNewsContent2, " ");

        // delete stop word, spaces, and blank new lines from arrays
        $mArray1 = $this->clearStopWords($mArray1);
        $mArray2 = $this->clearStopWords($mArray2);

        $mAvgWords = (count($mArray1) + count($mArray2))/2;
        $duplicateWords = $this->checkDuplicates($mArray1, $mArray2);
        $dupCount = count($duplicateWords);
        $output = "<div class = \"alert alert-success\">".
            "<p>".
            "تعداد واژه های متن اول: ".count($mArray1).
            "</p>".
            "<p>".
            "تعداد واژه های متن دوم: ".count($mArray2).
            "</p>".
            "<p>".
            "میانگین تعداد کل واژه های دو متن: ".$mAvgWords.
            "</p>".
            "<p>".
            "تعداد واژه های تکراری: ".$dupCount.
            "</p>".
            "<p>".
            "درصد تشابه دو متن: ".(($dupCount/$mAvgWords)*100)."%".
            "</p>".
            "</div>\n";
        print($output);
        $this->printDupWords($duplicateWords);
    }

    /**
     * Print News' Text
     * 
     * @return void
     */
    public function printNewsContent()
    {
        echo "<div class = \"m-1 p-3 border\">\n";
        echo "<p style=\"text-align: justify; text-justify: inter-word;\">". $this->mNewsContent1 ."</p>\n";
        echo "</div>\n";
        echo "<div class = \"m-1 p-3 border\">\n";
        echo "<p style=\"text-align: justify; text-justify: inter-word;\">". $this->mNewsContent2 ."</p>\n";
        echo "</div>\n";
    }

    /**
     * print duplicate words
     */
    private function printDupWords($arr)
    {
        echo "<div class = \"card mt-2 p-3\">\n";
        echo "<h3>کلمات مشابه:</h3>";
        foreach($arr as $word){
            echo "".$word." , ";
        }
        echo "</div>";
    }

    /**
     * load stop words and create array from them
     *
     * @return array
     */
    private function openStopWords()
    {
        $arr = array();
        $mFile = fopen("stopwords.txt", "r") or die("خطا در بازگشایی فایل ایست واژه ها!!");
        // Output one line until end-of-file
        while(!feof($mFile)) {
            array_push($arr, fgets($mFile));
        }
        fclose($mFile);
        return $arr;
    }

    /**
     * Remove a Special String or Character from string
     *
     * @param [type] $text
     * @param [type] $rmv
     * @return string
     */
    private function removeCharString($text, $rmv)
    { 
            return mb_substr($text, 0, mb_stripos($text, $rmv))." ".mb_substr($text, mb_stripos($text, $rmv)+1, mb_strlen($text));
    }

    /**
     * Split a string to array by a seperator
     *
     * @param [type] $text
     * @param [type] $seperator
     * @return array
     */
    private function splitToArray($text, $seperator)
    {
        return explode($seperator, $text);
    }

    /**
     * remove stop words, space, and blank new lines from the content
     *
     * @param [type] $arr
     * @return array
     */
    private function clearStopWords($arr)
    {
        $nArr = array();
        foreach($arr as $word){
            // remove stop words
            $isStop = false;
            $isSpace = false;
            foreach($this->stopWords as $stopWord){
                if(strpos($stopWord, $word) !== false){
                    $isStop = true;
                    break;
                }
            }

            if(strpos($word, " ") !== false){
                // remove spcae
                $isSpace = true;
            }else if(strpos($word, "\n") !== false){
                // remove new lines
                $isSpace = true;
            }
            if(!$isStop && !$isSpace){
                array_push($nArr, $word);
            }
        }
        return $nArr;
    }

    /**
     * check duplicate words between two news' content
     *
     * @param [type] $arr1
     * @param [type] $arr2
     * @return array
     */
    private function checkDuplicates($arr1, $arr2)
    {
        $isDuplicate = false;
        $dupWords = array();
        foreach($arr1 as $word1){
            $isDuplicate = false;
            foreach($arr2 as $word2){
                if(strpos($word1, $word2) !== false){
                    $isDuplicate = true;
                    break;
                }
            }
            if($isDuplicate){
                array_push($dupWords, $word1);
            }
        }
        return $dupWords;
    }
}
